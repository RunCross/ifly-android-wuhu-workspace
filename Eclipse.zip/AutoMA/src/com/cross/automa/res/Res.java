package com.cross.automa.res;

public class Res {

	public static String url_head ;
	public static final String url_login = "/connect/app/";
//	public static final String url_
//	public static final String 
//	public static final String 
//	public static final String 
	
}
