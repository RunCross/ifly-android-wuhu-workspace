package run.cross.autorefuse;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;

@SuppressWarnings("deprecation")
public class MainActivity extends TabActivity {

    @SuppressWarnings("deprecation")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TabHost tab = getTabHost();
        //TabSpec tabs1 = tab.newTabSpec("tab1").setIndicator("����").setContent(R.id.tab1);
        //tabs1.setContent(new Intent(this,SstartActivity.class));
        //tab.addTab(tabs1);
        TabSpec tabs1 =tab
		.newTabSpec("tab1")
		.setIndicator("����",
				getResources()
				.getDrawable(R.drawable.ic_launcher))
		.setContent(new Intent(this,SstartActivity.class));        
        tab.addTab(tabs1);        
        TabSpec tabs2 = tab.newTabSpec("tab2").setIndicator("�û���").setContent(R.id.tab2);
        tab.addTab(tabs2);
        TabSpec tabs3 = tab.newTabSpec("tab2").setIndicator("����").setContent(R.id.tab3);
        tab.addTab(tabs3);
        tab.setOnTabChangedListener(new OnTabChangeListener() {
			
			@Override
			public void onTabChanged(String arg0) {
				// TODO Auto-generated method stub
				
			}
		});
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    
    
}
