package run.cross.fly.res;

public class Res {

	public static final String url = "http://sms.xudan123.com/do.aspx";	
}
